rigctl -m 2 -r localhost:4532 T 0
rigctl -m 2 -r localhost:4532 T 1

