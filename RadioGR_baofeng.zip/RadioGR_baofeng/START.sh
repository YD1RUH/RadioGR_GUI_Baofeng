clear
ls -la /dev/ttyUSB*
echo ""
read -p "masukkan port COM terdeteksi         : " port
read -p "masukkan baudrate minimodem listener : " baud
xterm -e "rigctld -m 1 -p $port -t 4532 -P RTS -vvvvv" &
xterm -e "sleep 0.5; rigctl -m 2 -r localhost:4532 T 1" &
xterm -e "minimodem --rx $baud -q" &
java -jar Minimodem_baofeng.jar &
